This video is from some testing using Kanthal A1 30GA wire; while 20GA 
was calculated to be sufficient, problems were encountered trying to 
get that diameter to heat up. 30GA responded better, despite the 
Design Calculations disagreeing with this behaviour; unfortunately, 
equipment such as multimeters required to further analyse this surprising 
behaviour could not be source (worth investigation in later studies)