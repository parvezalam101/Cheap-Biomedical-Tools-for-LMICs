These files were specifically used alongside the Design Calculations Excel
document to thermally model the device; Page 2 in this document summarises
the CAD inputs which should be changed in order to tailor the device to 
your own calculations

Please note that the connector between the brass rods was used to force 
Solid Edge 2021 to properly display behaviour in both rods; in reality, 
this small connector should NOT be present as it would prevent current 
flow to the resistance wire. 

Thermal simulations can then be carried out within the Simulation tab in 
Solid Edge 2021; for a less resource-intensive simulation, a simplified 
model (Working Pen Thermal Analysis) has been created.